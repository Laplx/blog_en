# -*- coding: utf-8 -*-
"""
Created on Mon Jul 10 13:05:22 2023

@author: Laplace
"""

import numpy as np
import matplotlib.pyplot as plt
import scipy.cluster.hierarchy as sch
from sklearn.decomposition import PCA
import adjustText

#%% count words
words = '或之其亦方于即皆因仍故尚乃呀吗咧啊罢么呢了的着一不把让向往是在别好可便就但越再更比很偏儿'

with open('gengchen.txt','r',encoding='utf-8') as f:
    count = []
    for line in f:
        if not line.isspace():
            chap_count = []
            for w in words:
                chap_count.append(line.count(w))
            count.append(chap_count)

print(len(count))
# chapter 17 and 18 were not distinguished in gengchen edition, so halve.
for i in range(43):
    count[16][i] = count[16][i]/2
count = count[:17] + count[16:]

with open('chengyi.txt','r',encoding='utf-8') as f2:
    count_chengyi = []
    for line in f2:
        if not line.isspace():
            chap_count = []
            for w in words:
                chap_count.append(line.count(w))
            count_chengyi.append(chap_count)

print(len(count_chengyi))
# integrate
count = count + count_chengyi[80:120]

#%% dump
# compute chi-square distance and cluster
X = np.array(count)

chic,chip = sf.chi2(X.T, np.arange(X.shape[1]).reshape(-1,1))
chid = np.zeros((X.shape[0],X.shape[0]))
for i in range(chic.shape[0]):
    chid[i,:] = chic[i] + chic
chid[np.eye(X.shape[0],dtype=np.bool)] = 0
D = ssd.squareform(chid)

Z = sch.linkage(D,method='average')

clus = sch.dendrogram(Z,labels=list(range(1,121)))
plt.savefig('cluster',dpi=300)

#%% clustering
# corrize
Xi = X.sum(axis=1)
Xj = X.sum(axis=0)
T = np.sum(Xi)
Xz = np.zeros(X.shape)
for i in range(X.shape[0]):
    for j in range(X.shape[1]):
        Xz[i][j] = (X[i][j] - Xi[i]*Xj[j]/T)/np.sqrt(Xi[i]*Xj[j])

plt.figure(figsize=(20,5))

Z = sch.linkage(Xz,method='average',metric='euclidean')

clus = sch.dendrogram(Z,labels=list(range(1,121)))
plt.xticks(fontsize=8)
plt.xlabel('chapter')
plt.ylabel('distance')
plt.title('Dendrogram')
plt.savefig('cluschi',dpi=400)

#%% pca
pca = PCA(n_components=2)
X2 = pca.fit_transform(Xz)
X2 = X2*1000
varr = np.sum(pca.explained_variance_ratio_) #0.47721258443460124

plt.figure(figsize=(12,12))
plt.scatter(X2[:,0],X2[:,1])

# add labels
num = ['%d'%(i+1) for i in range(X2.shape[0])]
texts = [plt.text(x,y,text,fontsize=8) for x, y, text in zip(X2[:,0],X2[:,1],num)]
adjustText.adjust_text(texts, 
            only_move={'text': 'x'},
            arrowprops=dict(arrowstyle='-', color='grey'))
# add seperating line
plt.plot([-35,70],[-11,30],c='blue',ls='-')

plt.title('Front View')
plt.savefig('scatt',dpi=300)