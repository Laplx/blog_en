# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 11:37:10 2023

@author: Laplace
"""
import re
import requests
from bs4 import BeautifulSoup as bs


# extract from each chapter
def ext(url):
    chap = requests.get(url)
    chap.encoding = 'gbk'
    soup = bs(chap.text,'html.parser')
    txt = soup.select('#Layer1 > table > tr:nth-child(2) > td > div > p > font')
    # patches: different path(ugly!)
    if txt == []:
        txt = soup.select('#Layer1 > table > tr:nth-child(2) > td > p > font')
    if txt == []:
        txt = soup.select('#Layer1 > table > tr:nth-child(2) > td > div > font')
    if txt == []:
        txt = soup.select('#Layer1 > table > tr:nth-child(2) > td > p > p > font')
    if txt == []:
        txt = soup.select('#Layer1 > table > tr:nth-child(2) > td > font > p')
    if txt == []:
        txt = soup.select('#Layer1 > table > tr:nth-child(2) > td > div > font > p')
    if txt == []:
        txt = soup.select('#Layer1 > div > table > tr:nth-child(2) > td > div > p > font')
    if txt == []:
        txt = soup.select('#Layer1 > div > table > tr:nth-child(2) > td > div > font > p')
    print(len(txt))
    if len(txt) != 1:
        a = ''
        for i in txt:
            a = a + str(i)
        txt = [a]
    txt = re.sub('<.+?>','',str(txt[0]))
    txt = ''.join(txt.split())
    return txt


# traverse, hard url
gengchen_hlm = []
for i in range(80):
    t = ext('http://www.redchamber.net/red/wx/%d.htm'%(i+1))
    gengchen_hlm.append(t)
    
print(len(gengchen_hlm))
with open('gengchen.txt','w',encoding='utf-8') as f:
    for t in gengchen_hlm:
        f.write(t)
        f.write('\n\n')